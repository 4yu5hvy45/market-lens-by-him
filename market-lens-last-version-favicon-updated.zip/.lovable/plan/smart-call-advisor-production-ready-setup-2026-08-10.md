# Smart Call Advisor — production-ready setup

## What I found in your upload

- The app is complete: public call board, call detail, checkout, closed calls, research, admin desk, Razorpay order + webhook handling, and two SQL migrations (calls, purchases, user_roles, public teaser view).
- **This Lovable project is still the blank template** — the uploaded code is not in it yet. Step 1 is importing it.
- **Per-call price already exists** in the admin panel: the call editor has an "Unlock price (₹)" field, saved to `calls.price_inr`, and the price used at checkout is always read from the database (never from the browser). There is no separate global "premium price" setting — per your answer, we keep it per-call.
- **The admin gate is currently broken for real use.** `src/components/admin-gate.tsx` checks the password `Beyond123` in the browser and stores a flag in `sessionStorage`, but every admin action on the server (`adminListCalls`, `adminSaveCall`, `publishCall`, `closeCall`, …) demands a signed-in Supabase account holding the `admin` role. There is no login page anywhere in the app, so in production the desk would load and then fail on save/publish. Since you want to keep a shared password, the fix is to move that password to the server.
- Razorpay has a built-in test fallback: with no keys set it creates fake orders. Once real keys exist that path is disabled automatically.

## Plan

### 1. Import the app into this project
Bring in all source (routes, components, lib, integrations, styles, config) and the two SQL migrations. Nothing from `.git` or the uploaded `.env` is copied — this project gets its own backend credentials.

### 2. Enable Lovable Cloud (backend)
Provisions a fresh database + storage for this project, then applies both migrations so `calls`, `purchases`, `user_roles`, `calls_public`, grants and RLS all exist. Supabase URL/keys are injected automatically — nothing for you to paste, and when handing over to the client they get their own Cloud project the same way.

### 3. Make the shared admin password real (server-side)
Keep one shared password, but stop trusting the browser:
- Password moves to a server-only secret `ADMIN_PASSWORD` (never in code, never in a `VITE_` variable), plus a generated `SESSION_SECRET` for the cookie.
- `/admin` unlock posts the password to a server function, compared timing-safely, and sets an encrypted httpOnly session cookie. A "Lock desk" action clears it.
- Admin server functions switch their authorization from "signed-in Supabase admin" to "valid admin session cookie", so saving, publishing and closing calls actually work. Admin data still never reaches an unlocked visitor because it is produced inside gated server functions.
- Changing the password later is a one-field secret update, no code change.

### 4. Wire Razorpay test mode (guided, step by step)
I'll walk you through it after the above is live:
1. Razorpay Dashboard → switch to **Test Mode** → Settings → API Keys → Generate Test Key. Copy `rzp_test_...` key id and the secret (shown once).
2. Save them as `RAZORPAY_KEY_ID` / `RAZORPAY_KEY_SECRET` in a secure form I open for you.
3. Settings → Webhooks → Add Webhook, URL `https://<your-app>/api/public/webhooks/razorpay`, events `payment.captured`, `payment.failed`, `order.paid`. You choose a strong random webhook secret, paste it in Razorpay, and save the same value as `RAZORPAY_WEBHOOK_SECRET`.
4. Test a purchase with Razorpay's test card (4111 1111 1111 1111, any future expiry/CVV) and confirm the call unlocks and the purchase row flips to `paid`.

Going live for the client is then only: swap the three secrets for their live values and re-point the webhook. No code edits.

### 5. Production hardening pass
- Seed the first admin-created call flow end to end (create draft → set price → publish → buy → close) and verify each step in the real preview.
- Confirm price is always server-read at checkout and that the test-payment shortcut is dead once keys exist.
- Head metadata (title/description/OG) per public route; `robots.txt` and canonical checks.
- Error/not-found boundaries on data routes so a backend hiccup never blanks the page.

## Technical notes

- Admin authorization becomes an encrypted `useSession` cookie checked inside each admin server function; `user_roles`/`has_role` stay in the schema unused so a real login can be added later without a migration.
- `calls` and `purchases` keep RLS with no anon/authenticated policies — all access goes through verified server code; the public teaser view `calls_public` stays the only anon-readable surface.
- Webhook stays under `/api/public/`, verifying the HMAC over the raw body before any write; updates are idempotent on `razorpay_order_id`.

## Trade-off you should know

A shared password means one secret for everyone: no per-person identity, no audit trail, no revoking a single person. It is fine for a single-operator desk. If the client will have more than one admin, say so and I'll add real logins later — the schema already supports it.
